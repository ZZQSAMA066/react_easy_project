// @ts-nocheck

import TableOutlined from '@ant-design/icons/TableOutlined'

export default {
  TableOutlined
}
    