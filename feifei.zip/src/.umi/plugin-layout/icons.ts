// @ts-nocheck

  import TableOutlined from '@ant-design/icons/es/icons/TableOutlined'
  export default {
    TableOutlined
  }