import _ from 'D:/demo/feifei/node_modules/antd/es/locale/pt_BR';
export default _;
