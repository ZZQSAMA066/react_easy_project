import _ from 'D:/demo/feifei/node_modules/antd/es/locale/fa_IR';
export default _;
