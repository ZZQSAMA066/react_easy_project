import 'D:/demo/feifei/node_modules/antd/es/result/style';
