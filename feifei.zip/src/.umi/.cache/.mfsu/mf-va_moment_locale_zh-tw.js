import _ from 'moment/locale/zh-tw';
export default _;
export * from 'moment/locale/zh-tw';
