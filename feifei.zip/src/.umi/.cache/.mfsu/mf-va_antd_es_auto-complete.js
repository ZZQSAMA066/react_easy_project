import _ from 'D:/demo/feifei/node_modules/antd/es/auto-complete';
export default _;
