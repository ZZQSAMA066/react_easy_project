import _ from 'D:/demo/feifei/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
export default _;
export * from 'D:/demo/feifei/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
