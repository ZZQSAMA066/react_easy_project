import _ from 'moment/locale/id';
export default _;
export * from 'moment/locale/id';
