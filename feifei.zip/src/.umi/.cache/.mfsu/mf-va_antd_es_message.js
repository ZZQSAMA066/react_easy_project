import _ from 'D:/demo/feifei/node_modules/antd/es/message';
export default _;
export * from 'D:/demo/feifei/node_modules/antd/es/message';
