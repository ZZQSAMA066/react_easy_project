import _ from 'D:/demo/feifei/node_modules/antd/es/locale/zh_CN';
export default _;
