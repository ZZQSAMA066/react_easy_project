import _ from 'D:/demo/feifei/node_modules/antd/es/locale/zh_TW';
export default _;
