import _ from 'D:/demo/feifei/node_modules/antd/es/locale/en_US';
export default _;
