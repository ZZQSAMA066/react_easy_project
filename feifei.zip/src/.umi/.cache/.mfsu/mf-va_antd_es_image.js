import _ from 'D:/demo/feifei/node_modules/antd/es/image';
export default _;
