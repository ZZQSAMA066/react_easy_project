import _ from 'D:/demo/feifei/node_modules/dumi-theme-default/es/builtins/Example.js';
export default _;
