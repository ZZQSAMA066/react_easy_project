import _ from 'D:/demo/feifei/node_modules/antd/es/spin';
export default _;
