import _ from 'D:/demo/feifei/node_modules/dumi-theme-default/es/builtins/Badge.js';
export default _;
