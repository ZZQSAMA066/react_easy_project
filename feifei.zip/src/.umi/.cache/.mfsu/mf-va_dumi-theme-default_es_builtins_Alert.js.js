import _ from 'D:/demo/feifei/node_modules/dumi-theme-default/es/builtins/Alert.js';
export default _;
