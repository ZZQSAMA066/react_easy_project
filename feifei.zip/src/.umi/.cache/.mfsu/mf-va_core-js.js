import _ from 'D:/demo/feifei/node_modules/core-js';
export default _;
export * from 'D:/demo/feifei/node_modules/core-js';
