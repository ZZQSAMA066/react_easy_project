import _ from 'D:/demo/feifei/node_modules/antd/es/tooltip';
export default _;
