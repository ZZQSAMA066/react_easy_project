export * from 'D:/demo/feifei/node_modules/@umijs/preset-dumi/lib/theme';
