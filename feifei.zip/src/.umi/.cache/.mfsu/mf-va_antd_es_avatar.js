import _ from 'D:/demo/feifei/node_modules/antd/es/avatar';
export default _;
export * from 'D:/demo/feifei/node_modules/antd/es/avatar';
