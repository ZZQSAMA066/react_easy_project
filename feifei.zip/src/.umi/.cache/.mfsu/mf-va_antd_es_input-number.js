import _ from 'D:/demo/feifei/node_modules/antd/es/input-number';
export default _;
