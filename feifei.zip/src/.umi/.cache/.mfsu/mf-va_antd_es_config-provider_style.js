import 'D:/demo/feifei/node_modules/antd/es/config-provider/style';
