import _ from 'D:/demo/feifei/node_modules/antd/es/locale/ja_JP';
export default _;
