import { useIntl } from 'umi';
import { GithubOutlined } from '@ant-design/icons';
import { DefaultFooter } from '@ant-design/pro-layout';
export default () => {
  return <div style={{ textAlign: 'center' }}>李脾气大宝里宝气</div>;
};
