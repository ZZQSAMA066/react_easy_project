import request from '../request';
import Error from '../Error';
import { baseUrl } from '../apiConfig';

async function fetchApi(data, url) {
  const userId = localStorage.getItem('teachUserId')
  const token = localStorage.getItem('teachToken')
  const realData = await request(`${baseUrl}${url}`, {
    method: 'POST',
    responseType: 'json',
    params: data,
  });
  // eslint-disable-next-line consistent-return
  return realData ;
}

export default fetchApi;
