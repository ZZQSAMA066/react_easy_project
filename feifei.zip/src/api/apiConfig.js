// const baseUrl = 'http://192.168.2.132:8081/'; // 开发环境 vb
// const baseUrl = 'https://oj-teach.shuisi110.com/' // 生产环境
const baseUrl = "http://192.168.2.128:9080/"
export { baseUrl };
