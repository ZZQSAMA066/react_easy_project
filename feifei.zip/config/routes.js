export default [
  {
    name: 'list.table-list',
    layout:false,
    path: '/mainView',
    component: './card',
  },
  {
    name: 'list.table-list',
    layout: false,
    icon: 'table',
    path: '/charts',
    component: './picture',
    hideInMenu: 'true',
  },
  {
    path: '/',
    layout: false,
    routes: [
      {
        name: 'login',
        path: '/',
        component: './login',
        hideInMenu: 'true',
      },
    ],
  },

  {
    component: './404',
  },
];
